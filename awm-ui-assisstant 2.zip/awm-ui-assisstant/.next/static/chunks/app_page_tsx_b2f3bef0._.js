(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e10bbd5d._.js",
  "static/chunks/node_modules_@assistant-ui_react_dist_6e4ea1d4._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
  "static/chunks/node_modules_assistant-stream_a9422308._.js",
  "static/chunks/node_modules_@radix-ui_21b02f02._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_00ea5081._.js",
  "static/chunks/node_modules_@assistant-ui_react-markdown_styles_dot_83a3e0f6.css"
],
    source: "dynamic"
});
